class Problem:
    def __init__(self, initial_state, goal_state=None):
        self.initial_state = initial_state
        self.goal_state = goal_state

    def actions(self, state):
        raise NotImplementedError(self.__class__.__name__)

    def result(self, state, action):
        raise NotImplementedError(self.__class__.__name__)

    def is_goal(self, state):
        if state == self.goal_state:
            return True
        else:
            return False

    def action_cost(self, state1, action, state2):
        return 1

    def h(self, node):
        return 0


class RouteProblem(Problem):
    def __init__(self, initial_state, goal_state=None,
                 map_graph=None,
                 map_coords=None):
        self.initial_state = initial_state
        self.goal_state = goal_state
        self.map_graph = map_graph
        self.map_coords = map_coords

    def actions(self, state):
        neighbours = []
        for (x, y) in self.map_graph:
            if x == state:
                neighbours.append(y)
        return neighbours

    def result(self, state, action):
        for (x, y) in self.map_graph:
            if x == state and y == action:
                return action
        return state

    def action_cost(self, state1, action, state2):
        if(state1, state2) in self.map_graph:
            return self.map_graph[(state1, state2)]
        else:
            return 0

    def h(self, node):
        if node == self.goal_state:
            return 0
        else:
            (x1, y1) = self.map_coords[node.state]
            (x2, y2) = self.map_coords[self.goal_state]
            distance = ((x1-x2) ** 2 + (y1-y2) ** 2)**(1/2)
            return distance


class GridProblem(Problem):
    def __init__(self, initial_state, N, M, wall_coords, food_coords):
        food_eaten = []
        for i in range(0, len(food_coords)):
            food_eaten.append(False)
        food_eaten = tuple(food_eaten)
        self.food_eaten = food_eaten
        self.initial_state = (initial_state, food_eaten)
        self.N = N
        self.M = M
        self.wall_coords = wall_coords
        self.food_coords = food_coords
        self.goal_state = None

    def actions(self, state):
        list = []
        (x, y) = state[0]

        if y < self.N and (x, (y+1)) not in self.wall_coords:
            list.append("up")
        if y > 1 and (x, y-1) not in self.wall_coords:
            list.append("down")
        if x < self.M and (x+1, y) not in self.wall_coords:
            list.append("right")
        if x > 1 and (x-1, y) not in self.wall_coords:
            list.append("left")
        return list

    def result(self, state, action):
        actions_list = self.actions(state)
        foodList = []
        if action not in actions_list[0]:
            return state
        else:
            (x, y) = state[0]
            theState = list(state)
            if action == "up":
                y = y+1
                theState[0] = (x, y)
            elif action == "down":
                y = y-1
                theState[0] = (x, y)
            elif action == "right":
                x = x+1
                theState[0] = (x, y)
            else:
                x = x-1
                theState[0] = (x, y)
            counter = 0
            for (x, y) in self.food_coords:
                if (x, y) == theState[0]:
                    foodList = list(theState[1])
                    foodList[counter] = True
                    foodList = tuple(foodList)
                    theState[1] = foodList
                counter = counter + 1

            # theState = tuple(theState)
            # self.food_eaten = theState[1]
        theState = tuple(theState)
        return theState

    def is_goal(self, state):
        listy = list(state[1])
        for item in listy:
            if item == False:
                return False
        return True

    def action_cost(self, state1, action, state2):
        return 1

    def h(self, node):
        distance = float('inf')
        (x2, y2) = node.state[0]
        if node.state[0] == self.goal_state:
            return 0
        else:
            counter = 0
            for (x1, y1) in self.food_coords:
                if len(node.state[1]) > counter:
                    if node.state[1][counter] == False:
                        manhattan = abs(x1 - x2) + abs(y1 - y2)
                        if distance > manhattan:
                            distance = manhattan
                    counter = counter + 1

            return distance
